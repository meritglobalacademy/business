📄 GitHub Pages Upload Instructions:

1. Go to your GitHub repository (business or personal).
2. Click 'Add file' > 'Upload files'.
3. Drag and drop the contents of the appropriate folder (Business or Personal).
4. Commit the changes.
5. Access your site via:
   - https://yourusername.github.io/business
   - https://yourusername.github.io/personal
